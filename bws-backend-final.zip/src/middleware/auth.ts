import { Request, Response, NextFunction } from "express"
import jwt from "jsonwebtoken"

export function requireAuth(req: Request, res: Response, next: NextFunction) {
  const h = req.headers.authorization || ""
  const token = h.startsWith("Bearer ") ? h.slice(7) : ""
  if (!token) return res.status(401).json({ error: "unauthorized" })
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET as string) as any
    ;(req as any).user = payload
    next()
  } catch {
    return res.status(401).json({ error: "invalid_token" })
  }
}
