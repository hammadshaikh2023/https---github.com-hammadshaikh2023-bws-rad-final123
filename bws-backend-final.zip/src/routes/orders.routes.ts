import { Router } from "express"
import { PrismaClient } from "@prisma/client"
import { z } from "zod"
import { requireAuth } from "../middleware/auth.js"

const prisma = new PrismaClient()
const router = Router()

router.get("/", requireAuth, async (req, res) => {
  const items = await prisma.salesOrder.findMany({ include: { items: true }, orderBy: { createdAt: "desc" } })
  res.json(items)
})

router.post("/", requireAuth, async (req, res) => {
  try {
    const body = z.object({
      orderNumber: z.string().min(1),
      customer: z.string().min(1),
      status: z.string().optional(),
      items: z.array(z.object({ productId: z.string(), quantity: z.number().int().positive(), price: z.number().nonnegative() })).min(1)
    }).parse(req.body)
    const total = body.items.reduce((s, i) => s + i.price * i.quantity, 0)
    const order = await prisma.salesOrder.create({
      data: {
        orderNumber: body.orderNumber,
        customer: body.customer,
        status: body.status || "pending",
        total,
        items: { create: body.items.map(i => ({ productId: i.productId, quantity: i.quantity, price: i.price })) }
      },
      include: { items: true }
    })
    res.status(201).json(order)
  } catch (e: any) {
    if (e.code === "P2002") return res.status(409).json({ error: "order_exists" })
    if (e.name === "ZodError") return res.status(400).json({ error: "validation_error", details: e.issues })
    res.status(500).json({ error: "server_error" })
  }
})

router.put("/:id/status", requireAuth, async (req, res) => {
  try {
    const body = z.object({ status: z.string().min(1) }).parse(req.body)
    const order = await prisma.salesOrder.update({ where: { id: req.params.id }, data: { status: body.status } })
    res.json(order)
  } catch (e: any) {
    if (e.name === "ZodError") return res.status(400).json({ error: "validation_error", details: e.issues })
    if (e.code === "P2025") return res.status(404).json({ error: "not_found" })
    res.status(500).json({ error: "server_error" })
  }
})

router.delete("/:id", requireAuth, async (req, res) => {
  try {
    await prisma.salesOrder.delete({ where: { id: req.params.id } })
    res.status(204).end()
  } catch (e: any) {
    if (e.code === "P2025") return res.status(404).json({ error: "not_found" })
    res.status(500).json({ error: "server_error" })
  }
})

export default router
