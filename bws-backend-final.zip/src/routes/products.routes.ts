import { Router } from "express"
import { PrismaClient } from "@prisma/client"
import { z } from "zod"
import { requireAuth } from "../middleware/auth.js"

const prisma = new PrismaClient()
const router = Router()

router.get("/", requireAuth, async (req, res) => {
  const items = await prisma.product.findMany({ orderBy: { createdAt: "desc" } })
  res.json(items)
})

router.post("/", requireAuth, async (req, res) => {
  try {
    const body = z.object({
      sku: z.string().min(1),
      name: z.string().min(1),
      description: z.string().optional(),
      price: z.number().nonnegative(),
      quantity: z.number().int().nonnegative()
    }).parse(req.body)
    const item = await prisma.product.create({ data: { ...body, price: body.price } })
    res.status(201).json(item)
  } catch (e: any) {
    if (e.code === "P2002") return res.status(409).json({ error: "sku_exists" })
    if (e.name === "ZodError") return res.status(400).json({ error: "validation_error", details: e.issues })
    res.status(500).json({ error: "server_error" })
  }
})

router.put("/:id", requireAuth, async (req, res) => {
  try {
    const body = z.object({
      sku: z.string().min(1).optional(),
      name: z.string().min(1).optional(),
      description: z.string().optional(),
      price: z.number().nonnegative().optional(),
      quantity: z.number().int().nonnegative().optional()
    }).parse(req.body)
    const item = await prisma.product.update({ where: { id: req.params.id }, data: body })
    res.json(item)
  } catch (e: any) {
    if (e.name === "ZodError") return res.status(400).json({ error: "validation_error", details: e.issues })
    if (e.code === "P2025") return res.status(404).json({ error: "not_found" })
    res.status(500).json({ error: "server_error" })
  }
})

router.delete("/:id", requireAuth, async (req, res) => {
  try {
    await prisma.product.delete({ where: { id: req.params.id } })
    res.status(204).end()
  } catch (e: any) {
    if (e.code === "P2025") return res.status(404).json({ error: "not_found" })
    res.status(500).json({ error: "server_error" })
  }
})

export default router
