import { Router } from "express"
import { PrismaClient } from "@prisma/client"
import { z } from "zod"
import { requireAuth } from "../middleware/auth.js"

const prisma = new PrismaClient()
const router = Router()

router.get("/", requireAuth, async (req, res) => {
  const items = await prisma.vendor.findMany({ orderBy: { createdAt: "desc" } })
  res.json(items)
})

router.post("/", requireAuth, async (req, res) => {
  try {
    const body = z.object({ name: z.string().min(1), email: z.string().email().optional(), phone: z.string().optional() }).parse(req.body)
    const item = await prisma.vendor.create({ data: body })
    res.status(201).json(item)
  } catch (e: any) {
    if (e.name === "ZodError") return res.status(400).json({ error: "validation_error", details: e.issues })
    res.status(500).json({ error: "server_error" })
  }
})

router.put("/:id", requireAuth, async (req, res) => {
  try {
    const body = z.object({ name: z.string().min(1).optional(), email: z.string().email().optional(), phone: z.string().optional() }).parse(req.body)
    const item = await prisma.vendor.update({ where: { id: req.params.id }, data: body })
    res.json(item)
  } catch (e: any) {
    if (e.name === "ZodError") return res.status(400).json({ error: "validation_error", details: e.issues })
    if (e.code === "P2025") return res.status(404).json({ error: "not_found" })
    res.status(500).json({ error: "server_error" })
  }
})

router.delete("/:id", requireAuth, async (req, res) => {
  try {
    await prisma.vendor.delete({ where: { id: req.params.id } })
    res.status(204).end()
  } catch (e: any) {
    if (e.code === "P2025") return res.status(404).json({ error: "not_found" })
    res.status(500).json({ error: "server_error" })
  }
})

export default router
