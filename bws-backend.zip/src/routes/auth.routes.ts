import { Router } from "express"
import { z } from "zod"
import { loginUser, registerUser } from "../auth.js"

const router = Router()

router.post("/register", async (req, res) => {
  try {
    const body = z.object({ name: z.string().min(2), email: z.string().email(), password: z.string().min(6) }).parse(req.body)
    const user = await registerUser(body.name, body.email, body.password)
    res.json({ id: user.id, name: user.name, email: user.email })
  } catch (e: any) {
    if (e.message === "email_exists") return res.status(409).json({ error: "email_exists" })
    if (e.name === "ZodError") return res.status(400).json({ error: "validation_error", details: e.issues })
    res.status(500).json({ error: "server_error" })
  }
})

router.post("/login", async (req, res) => {
  try {
    const body = z.object({ email: z.string().email(), password: z.string().min(6) }).parse(req.body)
    const result = await loginUser(body.email, body.password)
    res.json(result)
  } catch (e: any) {
    if (e.message === "invalid_credentials") return res.status(401).json({ error: "invalid_credentials" })
    if (e.name === "ZodError") return res.status(400).json({ error: "validation_error", details: e.issues })
    res.status(500).json({ error: "server_error" })
  }
})

export default router
