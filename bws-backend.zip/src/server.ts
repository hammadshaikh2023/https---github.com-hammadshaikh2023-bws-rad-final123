import "dotenv/config"
import express from "express"
import cors from "cors"
import authRoutes from "./routes/auth.routes.js"
import productRoutes from "./routes/products.routes.js"
import vendorRoutes from "./routes/vendors.routes.js"
import orderRoutes from "./routes/orders.routes.js"

const app = express()
app.use(cors())
app.use(express.json())

app.get("/", (req, res) => res.json({ ok: true }))

app.use("/api/auth", authRoutes)
app.use("/api/products", productRoutes)
app.use("/api/vendors", vendorRoutes)
app.use("/api/sales-orders", orderRoutes)

const port = process.env.PORT || 4000
app.listen(port, () => {})
